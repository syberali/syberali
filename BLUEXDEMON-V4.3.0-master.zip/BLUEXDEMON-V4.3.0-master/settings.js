const version = require("@whiskeysockets/baileys/package.json").version
//Input number for pair code
global.pairingNumber = "923192084504"

global.botNumber = ["923192084504"]
global.domain = "https://.nobodysey.me"
global.apikey = "ptla_DfGlmoY7jCzmkNUgyK925FPVE08Kr4mxwLMep"
global.capikey = "ptlc_GTm42E3qIwbLW3K9w3htljUvhGvnG71hoPTqE"
global.egg = "15"
global.loc = "1"
global.anticall = ture
global.autoReadChat = false
global.alwaysonline = true
global.autoswview = false
global.public = false
global.autoreact = false
global.antidelete = ture
global.autotyping = false
global.autoBio = false
global.antiSpam = true
global.sign = "👿💀"
// ☞ ➻ ➽ ☛ 〆 
global.bank = "Opay"
global.bankname = "𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃"
global.accnumber = "923192084504"
global.language = "en"
global.sessionName = "session"
global.pairingCode = true 
global.runWith = "𝙽𝙾𝙳𝙴.𝙹𝚂"
global.newsletterJid = "120363304326105871@newsletter"
global.newsletterName = "𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃
global.caption = "𝙿𝚘𝚠𝚎𝚛𝚎𝚍 𝚋𝚢 MR 𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃 "
global.ownerName = "𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃"
global.syt = ''
global.sgc = '
global.sig = ''
global.web = '
//setbot
global.botName = "𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃" 
global.wm = "𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃"
global.fake = botName
global.setmenu = "image" 
global.docType = "application/vnd.ms-excel"
global.themeemoji = '💀'
global.fotoRandom = [
"https://www.imghippo.com/i/Vlt1653uPY.jpg",
https://www.imghippo.com/i/Vlt1653uPY.jpg"]
global.baileysMd = true
global.multi = false
global.prefa = "!"
global.Console = false
global.autorespon = false
global.copyright = `𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃 BOT`
global.baileysVersion = `${themeemoji}Baileys ${version}`
global.On = "On"
global.Off ="Off"
global.autoblockcmd = false
global.fake1 ="Bot WhatsApp"
global.packName = `𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃`
global.authorName = "𝚸𝚫𝐒𝐒𝐖𝚯𝚪𝐃 𝚮𝚫𝐂𝐊𝚵𝐃"
global.replyType = "web"
global.setwelcome = "type1"
global.autoblockcmd = false
global.autoReport = false
global.autoLevel = true
global.autoSticker = false
global.gamewaktu = 60
global.limitCount = 30
global.Intervalmsg = 1000
global.gris = '`'
global.fileStackApi ="AVKHbeyXsT0G9IKI01qenz"

global.skizo = 'memberaja'
global.Betabotz = 'LSd7Lq9S'
global.Lolhuman = '652c7664865e2b0e70929768',
global.FilestackApi = 'AJgyzwz0FQk67sTuplYoiz'  
global.gcounti = {
'prem' : 1000,
'user' : 5
} 
 



let d = new Date();
      let locale = "en";
      let gmt = new Date(0).getTime() - new Date("1 January 2024").getTime();
      let week = d.toLocaleDateString(locale, { weekday: "long" });
      const calender = d.toLocaleDateString("en", {
      day: "numeric",
      month: "long",
      year: "numeric",
      });

global.calender = calender;

const fs = require("fs");
const { color } = require("./lib/color");
const chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
